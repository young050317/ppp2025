import math

r=int(input("반지름을 입력하시오.==>"))

area=pi*pow(r,2)

print("원의 넓이는 {}입니다.".format(area))