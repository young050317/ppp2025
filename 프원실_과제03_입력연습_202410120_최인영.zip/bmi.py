weight=int(input("몸무게를 입력하시오.==>"))
height=int(input("키를 입력하시오.==>"))

height_m=height/100

import math
bmi=weight/math.pow(height_m,2)

print("몸무게={},키={}일 떄, bmi={}".format(weight,height,bmi))