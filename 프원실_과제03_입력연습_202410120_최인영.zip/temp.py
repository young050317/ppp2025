temp_c=int(input("온도를 입력하시요.==>"))
temp_f=(temp_c*1.8)+32

print("{}ºC=>{}Fº".format(temp_c,temp_f))