import math

x1=int(input("A점의 x좌표를 입력하시오.=>"))
y1=int(input("A점의 y좌표를 입력하시오.=>"))
x2=int(input("B점의 x좌표를 입력하시오.=>"))
y2=int(input("B점의 y좌표를 입력하시오.=>"))

distance=math.sqrt((x2-x1)**2+(y2-y1)**2)

print("A({},{}), B({},{}) 사이의 거리는 {}입니다.".format(x1,y1,x2,y2,distance))