han=int(input("한라봉 몇g을 섭취했나요?"))
berry=int(input("딸기 몇g을 섭취했나요?"))
banana=int(input("바나나 몇g을 섭취했나요?"))

han_cal=50/100*han
berry_cal=34/100*berry
banana_cal=77/100*banana

total_cal=han_cal+berry_cal+banana_cal

print("한라봉 {}g, 칼로리={}".format(han,han_cal))
print("딸기 {}g, 칼로리={}".format(berry,berry_cal))
print("바나나 {}g, 칼로리={}".format(banana,banana_cal))
print("총 칼로리는 {}입니다".format(total_cal))